package com.cis.project.proyecto_cis.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.cis.project.proyecto_cis.model.Paciente;
import com.cis.project.proyecto_cis.repository.PacienteRepository;

@Service
public class PacienteService {
    private final PacienteRepository repository;

    public PacienteService(PacienteRepository repository) {
        this.repository = repository;
    }

    public Paciente guardar(Paciente paciente) {
        return repository.save(paciente);
    }

    public List<Paciente> listarTodos() {
        return repository.findAll();
    }

    public Optional<Paciente> buscarPorId(Long id) {
        return repository.findById(id);
    }

    public List<Paciente> buscarPorNombreODocumento(String query) {
        return repository.findByNombresContainingIgnoreCaseOrApellidosContainingIgnoreCase(query, query);
    }

    public void eliminar(Long id) {
        repository.deleteById(id);
    }
}
