package com.cis.project.proyecto_cis.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cis.project.proyecto_cis.model.Paciente;

public interface PacienteRepository extends JpaRepository<Paciente, Long> {
    List<Paciente> findByNombresContainingIgnoreCaseOrApellidosContainingIgnoreCase(String nombres, String apellidos);
}
