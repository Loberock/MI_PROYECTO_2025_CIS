// Toggle del Sidebar
const sidebarToggle = document.getElementById('sidebarToggle');
if (sidebarToggle) {
    sidebarToggle.addEventListener('click', event => {
        event.preventDefault();
        document.getElementById('wrapper').classList.toggle('toggled');
    });
}

// Navegación entre secciones
const menuLinks = document.querySelectorAll('#menu-links .list-group-item');
const contentSections = document.querySelectorAll('.content-section');

menuLinks.forEach(link => {
    link.addEventListener('click', event => {
        event.preventDefault();

        const targetId = link.getAttribute('data-target');

        // Ocultar todas las secciones y quitar clase activa de los links
        contentSections.forEach(section => section.classList.remove('active'));
        menuLinks.forEach(menuLink => menuLink.classList.remove('active'));

        // Mostrar la sección correcta y activar el link
        document.getElementById(targetId + '-section').classList.add('active');
        link.classList.add('active');
    });
});

// Registrar pacientes
document.addEventListener("DOMContentLoaded", function () {
    const modal = new bootstrap.Modal(document.getElementById("modalPaciente"));
    const form = document.getElementById("formPaciente");

    // Botón "Añadir Paciente"
    document.querySelector("#pacientes-section .btn.btn-primary").addEventListener("click", () => {
        form.reset(); // Limpiar el formulario
        modal.show();
    });

    // Envío del formulario
    form.addEventListener("submit", function (e) {
        e.preventDefault();

        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());

        // Validación de fecha (opcional)
        if (!data.fechaNacimiento) {
            alert("Por favor, seleccione una fecha de nacimiento.");
            return;
        }

        // Enviar al backend
        fetch("http://localhost:8080/api/pacientes", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data)
        })
            .then(res => {
                if (!res.ok) throw new Error("Error al registrar el paciente.");
                return res.json();
            })
            .then(paciente => {
                alert("Paciente registrado correctamente.");
                modal.hide();
                agregarFilaPaciente(paciente); // Opcional: actualizar la tabla sin recargar
            })
            .catch(err => alert(err.message));
    });

    function agregarFilaPaciente(p) {
        const tbody = document.querySelector("#tabla-pacientes tbody");
        const fila = document.createElement("tr");

        fila.innerHTML = `
    <td>${p.id}</td>
    <td>${p.nombre} ${p.apellidos}</td>
    <td>${p.numeroDocumento || ""}</td>
    <td>${p.telefono || ""}</td>
    <td>${p.direccion || ""}</td>
    <td>${p.fechaNacimiento}</td>
    <td>${p.genero || ""}</td>
    <td>${p.fechaRegistro ? p.fechaRegistro.replace('T', ' ').substring(0, 16) : ""}</td>
    `;

        tbody.appendChild(fila);
    }
});
