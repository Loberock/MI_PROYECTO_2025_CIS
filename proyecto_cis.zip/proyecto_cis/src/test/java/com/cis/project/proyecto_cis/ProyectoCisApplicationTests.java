package com.cis.project.proyecto_cis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoCisApplicationTests {

	@Test
	void contextLoads() {
	}

}
